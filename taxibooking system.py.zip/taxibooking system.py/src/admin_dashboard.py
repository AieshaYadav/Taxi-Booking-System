import tkinter as tk
from tkinter import messagebox
from tkinter import ttk
from database.db_util import fetch_query, execute_query

def assign_driver(booking_id, driver_id):
    if is_driver_available(driver_id):
        query = "UPDATE bookings SET driver_id = %s, status = 'Assigned' WHERE id = %s"
        driver_query = "UPDATE drivers SET is_available = 0 WHERE id = %s"
        try:
            execute_query(query, (driver_id, booking_id))
            execute_query(driver_query, (driver_id,))
            messagebox.showinfo("Success", "Driver assigned successfully!")
        except Exception as e:
            messagebox.showerror("Error", f"Could not assign driver. Error: {e}")
    else:
        messagebox.showerror("Error", "Driver is not available.")

def is_driver_available(id):
    query = "SELECT * FROM drivers WHERE id = %s"
    try:
       result = fetch_query(query, (id,))
       return result[0]["is_available"]
    except Exception as e:
        messagebox.showerror("Error", "Error while fetching driver availability.")

def admin_dashboard(admin_id):
    """
    Displays the admin dashboard for managing bookings and drivers.
    """
    root = tk.Tk()
    root.title("Admin Dashboard")
    root.geometry("900x700")
    root.config(bg="#e8f5e9")  # Set a soft green background for the app

    # Header
    header_frame = tk.Frame(root, bg="#388e3c", pady=10)
    header_frame.pack(fill="x")
    tk.Label(header_frame, text="Admin Dashboard", font=("Arial", 24, "bold"), fg="white", bg="#388e3c").pack()

    # Listboxes for Bookings and Drivers
    list_frame = tk.Frame(root, bg="#e8f5e9")
    list_frame.pack(pady=20)

    bookings_list = tk.Listbox(list_frame, width=80, height=15, font=("Arial", 12), selectmode=tk.SINGLE)
    drivers_list = tk.Listbox(list_frame, width=80, height=15, font=("Arial", 12), selectmode=tk.SINGLE)

    bookings_list.pack(side=tk.LEFT, padx=10)
    drivers_list.pack(side=tk.LEFT, padx=10)

    # Scrollbars for Listboxes
    bookings_scrollbar = tk.Scrollbar(bookings_list)
    bookings_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    bookings_list.config(yscrollcommand=bookings_scrollbar.set)
    bookings_scrollbar.config(command=bookings_list.yview)

    drivers_scrollbar = tk.Scrollbar(drivers_list)
    drivers_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    drivers_list.config(yscrollcommand=drivers_scrollbar.set)
    drivers_scrollbar.config(command=drivers_list.yview)

    # Functions to show drivers and bookings
    def show_drivers():
        drivers = fetch_query("SELECT * FROM drivers WHERE is_available = 1")
        drivers_list.delete(0, tk.END)
        for driver in drivers:
            drivers_list.insert(tk.END, f"ID: {driver['id']} | {driver['name']}")

    def show_bookings():
        bookings = fetch_query("SELECT * FROM bookings WHERE status = 'Pending'")
        bookings_list.delete(0, tk.END)
        for booking in bookings:
            bookings_list.insert(tk.END, f"ID: {booking['id']} | Customer: {booking['customer_id']} | {booking['pickup_location']} to {booking['dropoff_location']}")

    # Buttons to view drivers and bookings
    button_frame = tk.Frame(root, bg="#e8f5e9")
    button_frame.pack(pady=20)

    tk.Button(button_frame, text="View Pending Bookings", command=show_bookings, font=("Arial", 14), bg="#388e3c", fg="white", relief="flat", width=20).pack(side=tk.LEFT, padx=20)
    tk.Button(button_frame, text="View Available Drivers", command=show_drivers, font=("Arial", 14), bg="#388e3c", fg="white", relief="flat", width=20).pack(side=tk.LEFT, padx=20)

    # Assign Driver Section
    assign_frame = tk.Frame(root, bg="#e8f5e9")
    assign_frame.pack(pady=20)

    tk.Label(assign_frame, text="Enter Booking ID:", font=("Arial", 12), bg="#e8f5e9").grid(row=0, column=0, padx=10, pady=10)
    booking_entry = tk.Entry(assign_frame, font=("Arial", 12), width=30)
    booking_entry.grid(row=0, column=1, padx=10)

    tk.Label(assign_frame, text="Enter Driver ID:", font=("Arial", 12), bg="#e8f5e9").grid(row=1, column=0, padx=10, pady=10)
    driver_entry = tk.Entry(assign_frame, font=("Arial", 12), width=30)
    driver_entry.grid(row=1, column=1, padx=10)

    tk.Button(assign_frame, text="Assign Driver", command=lambda: assign_driver(booking_entry.get(), driver_entry.get()), font=("Arial", 14), bg="#388e3c", fg="white", relief="flat", width=20).grid(row=2, columnspan=2, pady=20)

    root.mainloop()
