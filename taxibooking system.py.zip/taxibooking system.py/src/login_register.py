import tkinter as tk
from tkinter import messagebox
from tkinter import ttk
from database.db_util import execute_query, fetch_query

def register_user(user_type, name, address, phone, email, password):
    """
    Registers a user in the database based on the user type.
    """
    if user_type == "Customer":
        query = """
        INSERT INTO customers (name, address, phone, email, password)
        VALUES (%s, %s, %s, %s, %s)
        """
        try:
            execute_query(query, (name, address, phone, email, password))
            messagebox.showinfo("Success", f"{user_type} registered successfully!")
        except Exception as e:
            messagebox.showerror("Error", f"Could not register {user_type}. Error: {e}")

    elif user_type == "Driver":
        query = """
        INSERT INTO drivers (name, phone, email, password)
        VALUES (%s, %s, %s, %s)
        """
        try:
            execute_query(query, (name, phone, email, password))
            messagebox.showinfo("Success", f"{user_type} registered successfully!")
        except Exception as e:
            messagebox.showerror("Error", f"Could not register {user_type}. Error: {e}")
        
    else:
        messagebox.showerror("Error", "Invalid user type selected. Please choose Customer or Driver.")

def login_user(user_type, email_or_username, password, root):
    """
    Logs in a user based on user type, with an added check for admin credentials.
    """
    # Admin login check
    if email_or_username == "admin@gmail.com" and password == "admin123":
        messagebox.showinfo("Success", "Admin logged in successfully!")
        root.destroy() 
        from .admin_dashboard import admin_dashboard
        admin_dashboard(admin_id=None)

    else:
        # For regular user (Customer/Driver) login
        if user_type == "Customer":
            query = "SELECT * FROM customers WHERE email = %s AND password = %s"
        elif user_type == "Driver":
            query = "SELECT * FROM drivers WHERE email = %s AND password = %s"
        else:
            return

        result = fetch_query(query, (email_or_username, password))
        if result:
            messagebox.showinfo("Success", f"{user_type} logged in successfully!")
            root.destroy()  # Close the login/register window
            # Redirect to the respective dashboard
            if user_type == "Customer":
                from .customer_dashboard import customer_dashboard
                customer_dashboard(result[0]['id'])
            elif user_type == "Driver":
                from .driver_dashboard import driver_dashboard
                driver_dashboard(result[0]['id'])
        else:
            messagebox.showerror("Error", "Invalid credentials. Please try again.")

def main_page():
    """
    Creates the main login and registration page.
    """
    root = tk.Tk()
    root.title("Taxi Booking System - Login/Register")
    root.geometry("600x450")
    root.config(bg="#e8f5e9")  # Soft light green background

    tab_control = ttk.Notebook(root)
    login_tab = ttk.Frame(tab_control)
    register_tab = ttk.Frame(tab_control)

    tab_control.add(login_tab, text="Login")
    tab_control.add(register_tab, text="Register")
    tab_control.pack(expand=1, fill="both")

    # Login Tab
    login_frame = ttk.Frame(login_tab, padding="20", style="TFrame")
    login_frame.pack(fill="both", expand=True)

    tk.Label(login_frame, text="Login", font=("Helvetica", 18, "bold"), fg="#2e7d32", bg="#e8f5e9").pack(pady=20)
    tk.Label(login_frame, text="User Type:", font=("Arial", 12), bg="#e8f5e9").pack(pady=5)
    user_type_login = ttk.Combobox(login_frame, values=["Customer", "Driver"], state="readonly", width=30)
    user_type_login.pack(pady=5)

    tk.Label(login_frame, text="Email/Username:", font=("Arial", 12), bg="#e8f5e9").pack(pady=5)
    email_or_username = tk.Entry(login_frame, font=("Arial", 12), width=30)
    email_or_username.pack(pady=5)

    tk.Label(login_frame, text="Password:", font=("Arial", 12), bg="#e8f5e9").pack(pady=5)
    password_login = tk.Entry(login_frame, show="*", font=("Arial", 12), width=30)
    password_login.pack(pady=5)

    tk.Button(login_frame, text="Login", font=("Arial", 12), bg="#388e3c", fg="white", relief="flat", width=20,
              command=lambda: login_user(user_type_login.get(), email_or_username.get(), password_login.get(), root)).pack(pady=15)

    # Register Tab
    register_frame = ttk.Frame(register_tab, padding="20", style="TFrame")
    register_frame.pack(fill="both", expand=True)

    tk.Label(register_frame, text="Register", font=("Helvetica", 18, "bold"), fg="#2e7d32", bg="#e8f5e9").pack(pady=20)
    tk.Label(register_frame, text="User Type:", font=("Arial", 12), bg="#e8f5e9").pack(pady=5)
    user_type_register = ttk.Combobox(register_frame, values=["Customer", "Driver"], state="readonly", width=30)
    user_type_register.pack(pady=5)

    tk.Label(register_frame, text="Name:", font=("Arial", 12), bg="#e8f5e9").pack(pady=5)
    name_register = tk.Entry(register_frame, font=("Arial", 12), width=30)
    name_register.pack(pady=5)

    tk.Label(register_frame, text="Address (for Customers):", font=("Arial", 12), bg="#e8f5e9").pack(pady=5)
    address_register = tk.Entry(register_frame, font=("Arial", 12), width=30)
    address_register.pack(pady=5)

    tk.Label(register_frame, text="Phone:", font=("Arial", 12), bg="#e8f5e9").pack(pady=5)
    phone_register = tk.Entry(register_frame, font=("Arial", 12), width=30)
    phone_register.pack(pady=5)

    tk.Label(register_frame, text="Email/Username:", font=("Arial", 12), bg="#e8f5e9").pack(pady=5)
    email_register = tk.Entry(register_frame, font=("Arial", 12), width=30)
    email_register.pack(pady=5)

    tk.Label(register_frame, text="Password:", font=("Arial", 12), bg="#e8f5e9").pack(pady=5)
    password_register = tk.Entry(register_frame, show="*", font=("Arial", 12), width=30)
    password_register.pack(pady=5)

    tk.Button(register_frame, text="Register", font=("Arial", 12), bg="#388e3c", fg="white", relief="flat", width=20,
              command=lambda: register_user(user_type_register.get(), name_register.get(), address_register.get(),
                                             phone_register.get(), email_register.get(), password_register.get())).pack(pady=15)

    # Apply style for ttk widgets (tabs, frames, buttons, etc.)
    style = ttk.Style()
    style.configure("TFrame", background="#e8f5e9")
    style.configure("TButton", font=("Arial", 12), padding=6, relief="flat", background="#388e3c", foreground="white")
    style.map("TButton", background=[("active", "#2c6b2f")])

    root.mainloop()
