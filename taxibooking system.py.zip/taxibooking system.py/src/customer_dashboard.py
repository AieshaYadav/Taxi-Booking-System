import tkinter as tk
from tkinter import messagebox
from database.db_util import execute_query, fetch_query

def book_trip(customer_id, pickup, dropoff, datetime):
    """
    Allows a customer to book a taxi.
    """
    query = """
    INSERT INTO bookings (customer_id, pickup_location, dropoff_location, date_time)
    VALUES (%s, %s, %s, %s)
    """
    try:
        execute_query(query, (customer_id, pickup, dropoff, datetime))
        messagebox.showinfo("Success", "Trip booked successfully!")
    except Exception as e:
        messagebox.showerror("Error", f"Could not book the trip. Error: {e}")

def view_bookings(customer_id):
    """
    Fetches and displays all bookings for a customer.
    """
    query = "SELECT * FROM bookings WHERE customer_id = %s"
    bookings = fetch_query(query, (customer_id,))
    return bookings

def cancel_booking(booking_id):
    """
    Allows a customer to cancel a booking.
    """
    query = "DELETE FROM bookings WHERE id = %s"
    try:
        execute_query(query, (booking_id,))
        messagebox.showinfo("Success", "Booking cancelled successfully!")
    except Exception as e:
        messagebox.showerror("Error", f"Could not cancel the booking. Error: {e}")

def customer_dashboard(customer_id):
    """
    Displays the customer dashboard with booking options.
    """
    root = tk.Tk()
    root.title("Customer Dashboard")
    root.geometry("600x600")
    root.config(bg="#f0f4f7")

    # Header Section
    header_frame = tk.Frame(root, bg="#4CAF50", pady=10)
    header_frame.pack(fill="x")
    header_label = tk.Label(header_frame, text="Customer Dashboard", font=("Arial", 18, "bold"), fg="white", bg="#4CAF50")
    header_label.pack()

    # Top Button Frame
    button_frame = tk.Frame(root, bg="#4CAF50")
    button_frame.pack(fill="x")

    def show_section(section):
        # Hide all sections
        book_trip_frame.pack_forget()
        bookings_frame.pack_forget()
        cancel_frame.pack_forget()
        
        # Show the selected section
        if section == "book_trip":
            book_trip_frame.pack(fill="x", pady=10)
        elif section == "view_bookings":
            bookings_frame.pack(fill="x", pady=10)
        elif section == "cancel_booking":
            cancel_frame.pack(fill="x", pady=10)

    # Buttons to switch between sections
    tk.Button(button_frame, text="Book a Trip", font=("Arial", 12), bg="#4CAF50", fg="white", command=lambda: show_section("book_trip")).pack(side="left", padx=10, pady=10)
    tk.Button(button_frame, text="View Bookings", font=("Arial", 12), bg="#4CAF50", fg="white", command=lambda: show_section("view_bookings")).pack(side="left", padx=10, pady=10)
    tk.Button(button_frame, text="Cancel Booking", font=("Arial", 12), bg="#d9534f", fg="white", command=lambda: show_section("cancel_booking")).pack(side="left", padx=10, pady=10)

    # Logout Button
    def logout():
        # Ask the user for confirmation before logging out
        response = messagebox.askyesno("Logout", "Are you sure you want to logout?")
        if response:  # If Yes is clicked
            root.destroy()  # Close the customer dashboard window

    tk.Button(button_frame, text="Logout", font=("Arial", 12), bg="#f44336", fg="white", command=logout).pack(side="right", padx=10, pady=10)

    # Book a Trip Section
    book_trip_frame = tk.Frame(root, padx=20, pady=20, bg="#f0f4f7")
    
    tk.Label(book_trip_frame, text="Book a Trip", font=("Arial", 14, "bold")).pack(pady=10)
    
    tk.Label(book_trip_frame, text="Pickup Location:", font=("Arial", 10)).pack(anchor="w", pady=5)
    pickup_entry = tk.Entry(book_trip_frame, font=("Arial", 12), width=30)
    pickup_entry.pack()

    tk.Label(book_trip_frame, text="Drop-off Location:", font=("Arial", 10)).pack(anchor="w", pady=5)
    dropoff_entry = tk.Entry(book_trip_frame, font=("Arial", 12), width=30)
    dropoff_entry.pack()

    tk.Label(book_trip_frame, text="Date & Time (YYYY-MM-DD HH:MM):", font=("Arial", 10)).pack(anchor="w", pady=5)
    datetime_entry = tk.Entry(book_trip_frame, font=("Arial", 12), width=30)
    datetime_entry.pack()

    tk.Button(book_trip_frame, text="Book Trip", font=("Arial", 12), bg="#4CAF50", fg="white", command=lambda: book_trip(
        customer_id, pickup_entry.get(), dropoff_entry.get(), datetime_entry.get()
    )).pack(pady=10)

    # View Bookings Section
    bookings_frame = tk.Frame(root, padx=20, pady=20, bg="#f0f4f7")

    tk.Label(bookings_frame, text="Your Bookings", font=("Arial", 14, "bold")).pack(pady=10)
    bookings_list = tk.Listbox(bookings_frame, width=80, height=10, font=("Arial", 12), bg="#e9f5e2", selectmode=tk.SINGLE)
    bookings_list.pack()

    tk.Button(bookings_frame, text="View Bookings", font=("Arial", 12), bg="#4CAF50", fg="white", command=lambda: show_bookings()).pack(pady=5)

    def show_bookings():
        bookings = view_bookings(customer_id)
        bookings_list.delete(0, tk.END)
        for booking in bookings:
            # Adding Date and Time along with the booking details
            booking_details = f"ID: {booking['id']} | {booking['pickup_location']} to {booking['dropoff_location']} | Date & Time: {booking['date_time']}"
            bookings_list.insert(tk.END, booking_details)

    # Cancel Booking Section
    cancel_frame = tk.Frame(root, padx=20, pady=20, bg="#f0f4f7")

    tk.Label(cancel_frame, text="Enter Booking ID to Cancel:", font=("Arial", 10)).pack(anchor="w", pady=5)
    cancel_entry = tk.Entry(cancel_frame, font=("Arial", 12), width=30)
    cancel_entry.pack()

    tk.Button(cancel_frame, text="Cancel Booking", font=("Arial", 12), bg="#d9534f", fg="white", command=lambda: cancel_booking(
        cancel_entry.get()
    )).pack(pady=10)


    # Footer Section
    footer_frame = tk.Frame(root, bg="#4CAF50", pady=10)
    footer_frame.pack(fill="x", side="bottom")
    footer_label = tk.Label(footer_frame, text="Thank you for using our service!", font=("Arial", 10), fg="white", bg="#4CAF50")
    footer_label.pack()

    root.mainloop()
