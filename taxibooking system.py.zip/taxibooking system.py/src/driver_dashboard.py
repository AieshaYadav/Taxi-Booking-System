import tkinter as tk
from tkinter import messagebox, ttk
from database.db_util import fetch_query, update_query

def view_driver_trips(driver_id):
    """
    Fetches and displays all trips assigned to a driver.
    """
    query = "SELECT * FROM bookings WHERE driver_id = %s AND status != 'completed'"
    trips = fetch_query(query, (driver_id,))
    return trips

def mark_trip_complete(trip_id):
    """
    Marks the selected trip as completed in the database.
    """
    query = "UPDATE bookings SET status = %s WHERE id = %s"
    # Pass 'completed' as a string correctly
    success = update_query(query, ('completed', trip_id))
    return success

def driver_dashboard(driver_id):
    """
    Displays the driver dashboard with a list of assigned trips.
    """
    # Root Window
    root = tk.Tk()
    root.title("Driver Dashboard")
    root.geometry("700x500")
    root.configure(bg="#f0f5f9")  # Light background color

    # Header
    header_frame = tk.Frame(root, bg="#0073e6", padx=10, pady=10)
    header_frame.pack(fill="x")

    tk.Label(header_frame, text="Driver Dashboard", font=("Arial", 20, "bold"), fg="white", bg="#0073e6").pack()
    tk.Label(header_frame, text="Your Assigned Trips", font=("Arial", 14), fg="white", bg="#0073e6").pack()

    # Content Frame
    content_frame = tk.Frame(root, bg="#f0f5f9", padx=10, pady=10)
    content_frame.pack(fill="both", expand=True)

    # Listbox with Scrollbar
    trips_frame = tk.Frame(content_frame, bg="#f0f5f9")
    trips_frame.pack(fill="both", expand=True)

    scrollbar = ttk.Scrollbar(trips_frame)
    scrollbar.pack(side="right", fill="y")

    trips_list = tk.Listbox(trips_frame, width=80, height=15, font=("Arial", 12), bg="white", fg="#333333", yscrollcommand=scrollbar.set, relief="solid", borderwidth=1)
    trips_list.pack(side="left", fill="both", expand=True)
    scrollbar.config(command=trips_list.yview)

    # Button Frame
    button_frame = tk.Frame(root, bg="#f0f5f9")
    button_frame.pack(pady=10)

    style = ttk.Style()
    style.configure("TButton", font=("Arial", 12), padding=5)

    def show_trips():
        trips = view_driver_trips(driver_id)
        trips_list.delete(0, tk.END)
        for trip in trips:
            trips_list.insert(tk.END, f"ID: {trip['id']} | {trip['pickup_location']} to {trip['dropoff_location']}")

    def complete_trip():
        selected = trips_list.curselection()
        if not selected:
            messagebox.showwarning("No Selection", "Please select a trip to complete.")
            return
        
        selected_trip = trips_list.get(selected)
        trip_id = int(selected_trip.split('|')[0].split(':')[1].strip())  # Extract trip ID

        if mark_trip_complete(trip_id):
            messagebox.showinfo("Success", f"Trip ID {trip_id} marked as completed successfully!")
            show_trips()  # Refresh list
        else:
            messagebox.showerror("Error", "Failed to mark the trip as complete.")

    # Buttons
    refresh_button = ttk.Button(button_frame, text="Refresh Trips", command=show_trips, style="TButton")
    refresh_button.grid(row=0, column=0, padx=10)

    complete_button = ttk.Button(button_frame, text="Complete Trip", command=complete_trip, style="TButton")
    complete_button.grid(row=0, column=1, padx=10)

    # Footer
    footer_frame = tk.Frame(root, bg="#0073e6", padx=10, pady=5)
    footer_frame.pack(fill="x", side="bottom")
    tk.Label(footer_frame, text="Taxi Booking System © 2024", font=("Arial", 10), fg="white", bg="#0073e6").pack()

    show_trips()  # Initial load
    root.mainloop()
