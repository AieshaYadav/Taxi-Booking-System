from src.login_register import main_page

if __name__ == "__main__":
    main_page()