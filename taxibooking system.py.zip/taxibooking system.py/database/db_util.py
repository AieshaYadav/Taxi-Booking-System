import mysql.connector
from mysql.connector import Error

def create_connection():
    """
    Establishes a connection to the MySQL database.
    Returns the connection object or raises an exception on failure.
    """
    try:
        connection = mysql.connector.connect(
            host="localhost",      # Replace with your MySQL host
            user="root",           # Replace with your MySQL username
            password="2036204220612065",   # Replace with your MySQL password
            database="TaxiBookingSystemFinal"
        )
        if connection.is_connected():
            print("Database connection successful.")
        return connection
    except Error as e:
        print(f"Error connecting to database: {e}")
        raise Exception(e)

def execute_query(query, values=None):
    """
    Executes a given SQL query (with optional parameters) on the database.
    """
    connection = None
    try:
        connection = create_connection()
        cursor = connection.cursor()
        if values:
            cursor.execute(query, values)
        else:
            cursor.execute(query)
        connection.commit()
        print("Query executed successfully.")
    except Error as e:
       raise Exception(e)
    finally:
        if connection and connection.is_connected():
            cursor.close()
            connection.close()

def fetch_query(query, values=None):
    """
    Executes a SELECT query and returns the result set.
    """
    connection = None
    try:
        connection = create_connection()
        cursor = connection.cursor(dictionary=True)
        if values:
            cursor.execute(query, values)
        else:
            cursor.execute(query)
        result = cursor.fetchall()
        return result
    except Error as e:
        print(f"Error fetching query: {e}")
        return []
    finally:
        if connection and connection.is_connected():
            cursor.close()
            connection.close()
def update_query(query, values=None):
    """
    Executes an UPDATE/INSERT/DELETE query and checks if rows were affected.
    Returns True if rows were updated successfully, otherwise False.
    """
    connection = None
    try:
        connection = create_connection()
        cursor = connection.cursor()
        if values:
            cursor.execute(query, values)
        else:
            cursor.execute(query)
        connection.commit()
        row_count = cursor.rowcount  # Number of rows affected
        if row_count > 0:
            print(f"Rows affected: {row_count}")
            return True
        else:
            print("No rows affected.")
            return False
    except Error as e:
        print(f"Error updating query: {e}")
        return False
    finally:
        if connection and connection.is_connected():
            cursor.close()
            connection.close()